#!/bin/bash

# Author: Sebastian Schmittner (stp.schmittner@gmail.com)
# Date: 2016.02.16
# LastAuthor: Sebastian Schmittner (stp.schmittner@gmail.com)
# LastDate: 2016.02.16
# Version: 0.0.1

# $1 clean email (e.g. test-mdanderson-org)

sudo php ./cacheToFileSystem.php "$1"