<?php
/*
	Desc: Returns a predefined server credential info.
	Author:	Sebastian Schmittner
	Date: - 
	Last Author: Sebastian Schmittner
	Last Date: 2014.11.08 13:16:00 (+01:00)
	Version: 0.0.2
*/

// Server credentials

$externalLink = "http://polyzoomer.mdanderson.org/";

?>
