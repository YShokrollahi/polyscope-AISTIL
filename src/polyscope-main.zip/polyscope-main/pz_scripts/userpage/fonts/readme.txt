
Open Sans Light from Google Servers
https://www.google.com/fonts#UsePlace:use/Collection:Open+Sans
 -> http://fonts.googleapis.com/css?family=Open+Sans:300
      -> http://fonts.gstatic.com/s/opensans/v13/DXI1ORHCpsQm3Vp6mXoaTegdm0LZdjqr5-oayXSOefg.woff2