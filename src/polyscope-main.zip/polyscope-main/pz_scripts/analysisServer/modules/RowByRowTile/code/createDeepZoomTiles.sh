time vips dzsave $1 ${1}deepzoom 
