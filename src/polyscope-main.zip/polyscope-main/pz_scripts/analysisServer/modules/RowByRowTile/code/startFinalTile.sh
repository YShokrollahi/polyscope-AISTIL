montage -limit area 14288 -limit memory 14288 \
_daRowByRowTile0.png \
-mode Concatenate -tile 1x Da_tiled.png
