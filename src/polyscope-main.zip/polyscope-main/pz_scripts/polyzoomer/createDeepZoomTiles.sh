# Author: Andreas Heindl
# Date: -
# LastAuthor: Sebastian Schmittner
# LastDate: 2014.07.24 15:06:23 (+02:00)
# Version: 0.0.1

time vips dzsave $1 ${1}deepzoom 
